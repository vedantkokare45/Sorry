const openBtn = document.getElementById("openBtn");
const message = document.getElementById("message");
const forgiveBtn = document.getElementById("forgiveBtn");
const response = document.getElementById("response");
const hearts = document.querySelector(".floating-hearts");

function createHeartBurst(count = 18) {
  const symbols = ["💗", "🌷", "💕", "✨", "🤍"];
  for (let i = 0; i < count; i++) {
    const el = document.createElement("span");
    el.textContent = symbols[Math.floor(Math.random() * symbols.length)];
    el.style.left = `${Math.random() * 100}vw`;
    el.style.bottom = `${-10 - Math.random() * 20}px`;
    el.style.fontSize = `${16 + Math.random() * 18}px`;
    el.style.animationDuration = `${3 + Math.random() * 3}s`;
    el.style.animationDelay = `${Math.random() * .8}s`;
    hearts.appendChild(el);
    setTimeout(() => el.remove(), 6500);
  }
}

openBtn.addEventListener("click", () => {
  message.classList.remove("hidden");
  openBtn.textContent = "Thank you for reading 💗";
  openBtn.disabled = true;
  createHeartBurst(22);
  setTimeout(() => message.scrollIntoView({ behavior: "smooth", block: "start" }), 120);
});

forgiveBtn.addEventListener("click", () => {
  response.textContent = "बस्स… एवढंच पुरेसं आहे. 🌷😊";
  createHeartBurst(30);
  forgiveBtn.textContent = "आता एक smile पण दे 😊";
  forgiveBtn.disabled = true;
});

setInterval(() => {
  if (!document.hidden) createHeartBurst(1);
}, 3500);
